import os
import traceback
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QMessageBox
try:  # Qt5
    from qgis.PyQt.QtWidgets import QAction
except ImportError:  # Qt6
    from qgis.PyQt.QtGui import QAction
MENU_NAME = "&OFC Offset Calculator"
class OfcOffsetPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), "icon.png")
        icon = QIcon(icon_path) if os.path.exists(icon_path) else QIcon()
        self.action = QAction(icon, "OFC Offset Calculator", self.iface.mainWindow())
        self.action.setObjectName("ofcOffsetCalculatorAction")
        self.action.triggered.connect(self.run)
        self.iface.addPluginToVectorMenu(MENU_NAME, self.action)
        self.iface.addPluginToMenu(MENU_NAME, self.action)
        self.iface.addToolBarIcon(self.action)
    def unload(self):
        if self.action is not None:
            self.iface.removePluginVectorMenu(MENU_NAME, self.action)
            self.iface.removePluginMenu(MENU_NAME, self.action)
            self.iface.removeToolBarIcon(self.action)
            self.action.deleteLater()
            self.action = None
    def run(self):
        try:
            from .ofc_offset_dialog import OfcOffsetDialog
            dlg = OfcOffsetDialog(self.iface)
            dlg.exec()
        except Exception:
            QMessageBox.critical(self.iface.mainWindow(), "OFC Offset Calculator - Error",
                                 traceback.format_exc())
