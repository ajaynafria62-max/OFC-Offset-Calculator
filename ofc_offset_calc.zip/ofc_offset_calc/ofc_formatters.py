import math
COORD_FORMATS = [
    ("Map units (point layer CRS)", "MAP", 3),
    ("Decimal degrees", "DD", 6),
    ("Degrees, minutes", "DM", 4),
    ("Degrees, minutes, seconds", "DMS", 2),
]
BEARING_RANGES = [
    ("0° to 360°", "0_360"),
    ("-180° to 180°", "pm180"),
    ("0° to 180° with E/W suffix", "ew"),
]
DMS_UNIT = "Degrees, minutes, seconds"
ANGLE_UNITS = {
    "Degrees": (1.0, "°"),
    "Radians": (math.pi / 180.0, " rad"),
    "Gon (gradians)": (400.0 / 360.0, " gon"),
    "Minutes of arc": (60.0, "′"),
    "Seconds of arc": (3600.0, "″"),
    "Turns (revolutions)": (1.0 / 360.0, " tr"),
    "Milliradians": (math.pi / 180.0 * 1000.0, " mrad"),
}
BEARING_UNITS = ["Degrees", DMS_UNIT] + [u for u in ANGLE_UNITS if u != "Degrees"]
def dms_string(value, kind, prec):
    """value in degrees (sign ignored). kind is 'DM' or 'DMS'. Integer arithmetic avoids '60.00' rollover errors."""
    prec = max(0, int(prec))
    scale = 10 ** prec
    if kind == "DMS":
        units = int(round(abs(value) * 3600.0 * scale))
        d, r = divmod(units, 3600 * scale)
        m, s_units = divmod(r, 60 * scale)
        s = s_units / float(scale)
        sec = ("%0*.*f" % (prec + 3, prec, s)) if prec > 0 else "%02d" % int(s)
        return "%d°%02d′%s″" % (d, m, sec)
    units = int(round(abs(value) * 60.0 * scale))
    d, m_units = divmod(units, 60 * scale)
    m = m_units / float(scale)
    mm = ("%0*.*f" % (prec + 3, prec, m)) if prec > 0 else "%02d" % int(m)
    return "%d°%s′" % (d, mm)
def coord_is_text(fmt):
    return fmt in ("DM", "DMS")
def format_coord(x, y, fmt, prec):
    """(x, y) -> (xv, yv). MAP/DD are numeric, DM/DMS are text (with N/S/E/W hemisphere)."""
    if fmt in ("MAP", "DD"):
        return round(x, prec), round(y, prec)
    xs = dms_string(x, fmt, prec) + (" E" if x >= 0 else " W")
    ys = dms_string(y, fmt, prec) + (" N" if y >= 0 else " S")
    return xs, ys
def bearing_is_text(rng, unit):
    return rng == "ew" or unit == DMS_UNIT
def format_bearing(az_deg, rng, unit, prec):
    """az_deg: azimuth 0..360 (clockwise from north). Returns a number or text."""
    az = az_deg % 360.0
    suffix = ""
    if rng == "0_360":
        a = az
    elif rng == "pm180":
        a = az if az <= 180.0 else az - 360.0
    else:  # "ew"
        if az <= 180.0:
            a = az
            if 0.0 < az < 180.0:
                suffix = " E"
        else:
            a = 360.0 - az
            suffix = " W"
    if unit == DMS_UNIT:
        s = dms_string(a, "DMS", prec)
        return ("-" + s if a < 0 else s) + suffix
    factor, sym = ANGLE_UNITS[unit]
    v = round(a * factor, prec)
    if rng == "0_360" and v >= 360.0 * factor:
        v = 0.0  # 359.999.. -> 0 instead of 360
    if v == 0:
        v = 0.0  # avoid '-0.0'
    if rng == "ew":
        return "%.*f%s%s" % (prec, v, sym, suffix)
    return v