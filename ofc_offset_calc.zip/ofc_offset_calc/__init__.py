def classFactory(iface):
    from .ofc_offset_plugin import OfcOffsetPlugin
    return OfcOffsetPlugin(iface)