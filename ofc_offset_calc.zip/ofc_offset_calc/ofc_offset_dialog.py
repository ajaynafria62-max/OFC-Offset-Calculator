import math
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QDialog, QDoubleSpinBox, QFormLayout,
    QGroupBox, QHBoxLayout, QLabel, QMessageBox, QProgressBar, QPushButton,
    QSpinBox, QTabWidget, QVBoxLayout, QWidget,
)
from qgis.core import (
    Qgis, QgsCoordinateReferenceSystem, QgsCoordinateTransform,
    QgsDistanceArea, QgsFeature, QgsMapLayerProxyModel, QgsMessageLog,
    QgsProject, QgsSpatialIndex, QgsUnitTypes, NULL,
)
from qgis.gui import QgsFieldComboBox, QgsMapLayerComboBox
from .ofc_formatters import (
    BEARING_RANGES, BEARING_UNITS, COORD_FORMATS, bearing_is_text,
    coord_is_text, format_bearing, format_coord,
)
LOG_TAG = "OFC Offset Calculator"
try:
    YES, NO = QMessageBox.StandardButton.Yes, QMessageBox.StandardButton.No
except AttributeError:  # older PyQt
    YES, NO = QMessageBox.Yes, QMessageBox.No
def _line_filter():
    try:
        return Qgis.LayerFilter.LineLayer
    except AttributeError:
        return QgsMapLayerProxyModel.LineLayer
def _point_filter():
    try:
        return Qgis.LayerFilter.PointLayer
    except AttributeError:
        return QgsMapLayerProxyModel.PointLayer
def _unit_list():
    """(label, QGIS distance unit) - works on both old and new QGIS versions."""
    names = [
        ("Meters", "Meters"), ("Kilometers", "Kilometers"), ("Centimeters", "Centimeters"),
        ("Millimeters", "Millimeters"), ("Feet", "Feet"), ("Yards", "Yards"),
        ("Miles", "Miles"), ("Nautical Miles", "NauticalMiles"),
    ]
    out = []
    for label, attr in names:
        try:
            unit = getattr(Qgis.DistanceUnit, attr)
        except AttributeError:
            unit = getattr(QgsUnitTypes, "Distance" + attr, None)
        if unit is not None:
            out.append((label, unit))
    return out
def _ellipsoid_choices():
    """[(acronym, description)] - the QGIS ellipsoid list (as in Project Properties)."""
    try:
        from qgis.core import QgsEllipsoidUtils
    except ImportError:
        return []
    out = []
    try:
        for d in QgsEllipsoidUtils.definitions():
            out.append((d.acronym, d.description))
    except Exception:
        try:
            out = [(a, "") for a in QgsEllipsoidUtils.acronyms()]
        except Exception:
            out = []
    return sorted(out, key=lambda t: (t[1] or t[0]).lower())
def is_text_field(fld):
    tn = fld.typeName().lower()
    return any(k in tn for k in ("string", "text", "char"))
def best_distance(pg, index, line_geoms, da):

    cand = index.nearestNeighbor(pg, 8)
    if not cand:
        return None
    bestp = min(pg.distance(line_geoms[cid]) for cid in cand)
    rect = pg.boundingBox()
    rect.grow(max(bestp * 1.05, 1e-9))
    ids = set(index.intersects(rect)) | set(cand)
    best = None
    for cid in ids:
        sl = pg.shortestLine(line_geoms[cid])
        if sl is None or sl.isNull() or sl.isEmpty():
            continue
        poly = sl.asPolyline()
        if len(poly) < 2:
            continue
        d = da.measureLength(sl)
        if best is None or d < best[0]:
            best = (d, poly[0], poly[-1])
    return best
def _to_db(v, spec):
    """Convert a Python value to what the target field type expects."""
    if v is None:
        return NULL
    if spec["text"]:
        return v if isinstance(v, str) else str(v)
    if spec["is_int"]:
        return int(round(v))
    return v
class OfcOffsetDialog(QDialog):
    def __init__(self, iface):
        super().__init__(iface.mainWindow())
        self.iface = iface
        self.setWindowTitle("OFC Offset Calculator")
        self.setMinimumWidth(520)
        self._units = _unit_list()
        self._build_ui()
        self._on_point_layer_changed(self.point_cb.currentLayer())
        self._use_measure_tool_settings()
        for sig in (self.point_cb.layerChanged, self.line_cb.layerChanged):
            sig.connect(self._update_info)
        for cb in (self.crs_cb, self.method_cb, self.ell_cb):
            cb.currentIndexChanged.connect(self._update_info)
        self._update_info()

    def _build_ui(self):
        tabs = QTabWidget()

        t1 = QWidget()
        f1 = QFormLayout(t1)
        self.line_cb = QgsMapLayerComboBox()
        self.line_cb.setFilters(_line_filter())
        f1.addRow("1. Line layer:", self.line_cb)
        self.point_cb = QgsMapLayerComboBox()
        self.point_cb.setFilters(_point_filter())
        self.point_cb.layerChanged.connect(self._on_point_layer_changed)
        f1.addRow("2. Point layer:", self.point_cb)
        self.field_cb = QgsFieldComboBox()
        f1.addRow("3. Distance column (point layer):", self.field_cb)
        self.sel_points_chk = QCheckBox("Selected points only")
        self.sel_lines_chk = QCheckBox("Selected lines only")
        f1.addRow(self.sel_points_chk)
        f1.addRow(self.sel_lines_chk)
        tabs.addTab(t1, "Layers")

        t2 = QWidget()
        f2 = QFormLayout(t2)
        self.unit_cb = QComboBox()
        for label, _u in self._units:
            self.unit_cb.addItem(label)
        f2.addRow("Distance unit:", self.unit_cb)
        self.method_cb = QComboBox()
        self.method_cb.addItems([
            "Ellipsoidal (accurate, geodesic)",
            "Planar (CRS units, projected CRS only)",
        ])
        self.method_cb.currentIndexChanged.connect(self._on_method_changed)
        self.method_cb.setToolTip(
            "Ellipsoidal = like the Measure Tool and $length (independent of the CRS).\n"
            "Planar = like length($geometry), flat measurement that depends on the CRS.")
        f2.addRow("Measurement method:", self.method_cb)
        self.ell_cb = QComboBox()
        f2.addRow("Ellipsoid:", self.ell_cb)
        self._fill_ellipsoids()
        self.crs_cb = QComboBox()
        self.crs_cb.addItems(["Point layer CRS", "Line layer CRS", "Project CRS"])
        f2.addRow("Measurement CRS:", self.crs_cb)
        self.max_spin = QDoubleSpinBox()
        self.max_spin.setDecimals(3)
        self.max_spin.setRange(0, 1e9)
        self.max_spin.setSpecialValueText("No limit")
        f2.addRow("Max distance (selected unit):", self.max_spin)
        self.decimals_spin = QSpinBox()
        self.decimals_spin.setRange(0, 10)
        self.decimals_spin.setValue(2)
        f2.addRow("Round distance to decimals:", self.decimals_spin)
        self.null_outside_chk = QCheckBox("Set the output columns to NULL for points beyond the max distance")
        self.null_outside_chk.setChecked(True)
        f2.addRow(self.null_outside_chk)
        self.proj_btn = QPushButton("Apply QGIS Measure Tool settings (Project CRS + ellipsoid + unit)")
        self.proj_btn.clicked.connect(self._use_measure_tool_settings)
        f2.addRow(self.proj_btn)
        self.info_lbl = QLabel("")
        self.info_lbl.setWordWrap(True)
        f2.addRow(self.info_lbl)
        tabs.addTab(t2, "Measurements")

        t3 = QWidget()
        v3 = QVBoxLayout(t3)
        self.coord_box = QGroupBox("Fill nearest-point coordinates (on the line)")
        self.coord_box.setCheckable(True)
        self.coord_box.setChecked(False)
        fc = QFormLayout(self.coord_box)
        self.x_cb = QgsFieldComboBox()
        self.x_cb.setAllowEmptyFieldName(True)
        self.y_cb = QgsFieldComboBox()
        self.y_cb.setAllowEmptyFieldName(True)
        fc.addRow("X / Longitude column:", self.x_cb)
        fc.addRow("Y / Latitude column:", self.y_cb)
        self.coord_fmt_cb = QComboBox()
        for label, _k, _p in COORD_FORMATS:
            self.coord_fmt_cb.addItem(label)
        self.coord_fmt_cb.currentIndexChanged.connect(self._on_coord_fmt_changed)
        fc.addRow("Coordinate display:", self.coord_fmt_cb)
        self.coord_prec = QSpinBox()
        self.coord_prec.setRange(0, 12)
        fc.addRow("Precision (decimals):", self.coord_prec)
        self.coord_note = QLabel("")
        self.coord_note.setWordWrap(True)
        fc.addRow(self.coord_note)
        v3.addWidget(self.coord_box)
        self.bear_box = QGroupBox("Fill bearing")
        self.bear_box.setCheckable(True)
        self.bear_box.setChecked(False)
        fb = QFormLayout(self.bear_box)
        self.bear_cb = QgsFieldComboBox()
        self.bear_cb.setAllowEmptyFieldName(True)
        fb.addRow("Bearing column:", self.bear_cb)
        self.bear_dir_cb = QComboBox()
        self.bear_dir_cb.addItems(["Point to line", "Line to point"])
        fb.addRow("Direction:", self.bear_dir_cb)
        self.bear_range_cb = QComboBox()
        for label, _k in BEARING_RANGES:
            self.bear_range_cb.addItem(label)
        fb.addRow("Bearing format:", self.bear_range_cb)
        self.bear_unit_cb = QComboBox()
        self.bear_unit_cb.addItems(BEARING_UNITS)
        fb.addRow("Angle unit:", self.bear_unit_cb)
        self.bear_prec = QSpinBox()
        self.bear_prec.setRange(0, 10)
        self.bear_prec.setValue(2)
        fb.addRow("Precision (decimals):", self.bear_prec)
        self.bear_note = QLabel("Bearing is measured clockwise from north.")
        self.bear_note.setWordWrap(True)
        fb.addRow(self.bear_note)
        v3.addWidget(self.bear_box)
        v3.addStretch(1)
        tabs.addTab(t3, "Coordinate && Bearing")
        self._on_coord_fmt_changed()
        self._on_method_changed()

        self.progress = QProgressBar()
        self.progress.setValue(0)
        self.status = QLabel("")
        self.status.setWordWrap(True)
        self.run_btn = QPushButton("Calculate")
        self.run_btn.clicked.connect(self.run_calculation)
        self.close_btn = QPushButton("Close")
        self.close_btn.clicked.connect(self.reject)
        btns = QHBoxLayout()
        btns.addStretch(1)
        btns.addWidget(self.run_btn)
        btns.addWidget(self.close_btn)
        lay = QVBoxLayout(self)
        lay.addWidget(tabs)
        lay.addWidget(self.progress)
        lay.addWidget(self.status)
        lay.addLayout(btns)
    def _fill_ellipsoids(self):
        self.ell_cb.clear()
        proj_ell = QgsProject.instance().ellipsoid() or "NONE"
        self.ell_cb.addItem("Project ellipsoid (%s)" % proj_ell, "")
        for acr, desc in _ellipsoid_choices():
            self.ell_cb.addItem("%s - %s" % (acr, desc) if desc else acr, acr)
    def _use_measure_tool_settings(self):
        """Match the QGIS Measure Tool: Project CRS + project ellipsoid + project distance unit."""
        proj = QgsProject.instance()
        self.ell_cb.setCurrentIndex(0)   # project ellipsoid
        self.crs_cb.setCurrentIndex(2)   # Project CRS
        ell = proj.ellipsoid()
        if (not ell or ell == "NONE") and not proj.crs().isGeographic():
            self.method_cb.setCurrentIndex(1)  # project ellipsoid is NONE -> Measure Tool is planar
        else:
            self.method_cb.setCurrentIndex(0)
        try:
            pu = proj.distanceUnits()
            for i, (_label, unit) in enumerate(self._units):
                if unit == pu:
                    self.unit_cb.setCurrentIndex(i)
                    break
        except Exception:
            pass
        self._update_info()
    def _update_info(self, *args):
        """CRS / ellipsoid diagnostics: shows likely causes of differences up front."""
        proj = QgsProject.instance()
        pell = proj.ellipsoid() or "NONE"
        pl, ll = self.point_cb.currentLayer(), self.line_cb.currentLayer()
        lines = ["Project CRS: %s | Project ellipsoid: %s" % (proj.crs().authid(), pell)]
        if pl is not None and ll is not None:
            lines.append("Point CRS: %s | Line CRS: %s" % (pl.crs().authid(), ll.crs().authid()))
            if pl.crs() != ll.crs():
                lines.append("! Point and line layers use different CRS - the plugin converts both "
                             "to the measurement CRS before measuring.")
        planar = self.method_cb.currentIndex() == 1
        if planar:
            lines.append("! Planar: the value depends on the CRS (like length($geometry)). "
                         "Choose Ellipsoidal to match the Measure Tool / $length.")
        else:
            sel = self.ell_cb.currentData()
            if sel and sel != pell:
                lines.append("! The ellipsoid differs from the project (%s vs %s) - results can "
                             "differ slightly from the Measure Tool." % (sel, pell))
            if not sel and pell == "NONE":
                lines.append("! The project ellipsoid is NONE: the Measure Tool measures planar, "
                             "while the plugin uses the CRS ellipsoid - results can differ. Set an "
                             "ellipsoid in Project Properties -> General -> Measurements.")
        self.info_lbl.setText("\n".join(lines))
    def _measure_tool_check(self, samples, work_crs, ctx, to_unit, dec):
        """Re-measure sample points with the Measure Tool settings (project CRS + ellipsoid)."""
        if not samples:
            return ""
        proj = QgsProject.instance()
        pcrs, pell = proj.crs(), proj.ellipsoid()
        if (not pell or pell == "NONE") and pcrs.isGeographic():
            return ""
        try:
            dam = QgsDistanceArea()
            dam.setSourceCrs(pcrs, ctx)
            dam.setEllipsoid(pell if pell else "NONE")
            tr = QgsCoordinateTransform(work_crs, pcrs, ctx)
            worst = 0.0
            for _fid, _exp, value, o, f in samples:
                m = dam.convertLengthMeasurement(dam.measureLine(tr.transform(o), tr.transform(f)),
                                                 to_unit)
                worst = max(worst, abs(m - value))
        except Exception:
            return ""
        if worst <= 0.51 * (10 ** (-dec)) + 1e-9:
            return "Measure Tool check: match OK (max difference %.4f)." % worst
        return ("Measure Tool mismatch: max difference %.4f (in the selected unit). On the "
                "Measurements tab press 'Apply QGIS Measure Tool settings' and run again." % worst)
    def _on_method_changed(self):
        self.ell_cb.setEnabled(self.method_cb.currentIndex() == 0)
    def _on_coord_fmt_changed(self):
        label, key, prec = COORD_FORMATS[self.coord_fmt_cb.currentIndex()]
        self.coord_prec.setValue(prec)
        if key in ("DM", "DMS"):
            self.coord_note.setText("With this format the columns must be TEXT (String) fields. "
                                    "Coordinates are written in geographic (lat/lon).")
        elif key == "DD":
            self.coord_note.setText("Coordinates are written in geographic (lat/lon).")
        else:
            self.coord_note.setText("Coordinates are written in the point layer's CRS.")
    def _on_point_layer_changed(self, layer):
        for cb in (self.field_cb, self.x_cb, self.y_cb, self.bear_cb):
            cb.setLayer(layer)
        if layer is not None and layer.fields().indexOf("ofc_offset") >= 0:
            self.field_cb.setField("ofc_offset")

    def _msg(self, text, level=None):
        level = level if level is not None else Qgis.Info
        self.iface.messageBar().pushMessage("OFC Offset", text, level=level, duration=10)
        QgsMessageLog.logMessage(text, LOG_TAG, level)
    def _error(self, text):
        QMessageBox.warning(self, "OFC Offset Calculator", text)
    def _ask(self, text):
        return QMessageBox.question(self, "OFC Offset Calculator", text, YES | NO, NO) == YES
    def _chosen_crs(self, point_layer, line_layer):
        choice = self.crs_cb.currentIndex()
        if choice == 0:
            return point_layer.crs()
        if choice == 1:
            return line_layer.crs()
        return QgsProject.instance().crs()
    @staticmethod
    def _auto_utm_crs(point_layer, line_layer, ctx):
        """Local UTM zone (from the data center) for geographic CRS."""
        wgs = QgsCoordinateReferenceSystem("EPSG:4326")
        for lyr in (point_layer, line_layer):
            ext = lyr.extent()
            if ext.isNull():
                continue
            try:
                ext = QgsCoordinateTransform(lyr.crs(), wgs, ctx).transformBoundingBox(ext)
            except Exception:
                continue
            c = ext.center()
            zone = max(1, min(60, int((c.x() + 180.0) // 6) + 1))
            epsg = (32600 if c.y() >= 0 else 32700) + zone
            crs = QgsCoordinateReferenceSystem("EPSG:%d" % epsg)
            if crs.isValid():
                return crs
        return None
    @staticmethod
    def _prep_field(layer, name, label, need_text, numeric_only, decimals, warnings):
        """Validate the column type and collect warnings about rounding/truncation."""
        if not name:
            raise ValueError("Please select the %s column." % label)
        idx = layer.fields().indexOf(name)
        if idx < 0:
            raise ValueError("%s: column '%s' was not found in the point layer." % (label, name))
        fld = layer.fields().at(idx)
        text = is_text_field(fld)
        if need_text and not text:
            raise ValueError("%s: column '%s' (type: %s) must be a TEXT (String) field because the "
                             "selected format produces text." % (label, name, fld.typeName()))
        if numeric_only and not fld.isNumeric():
            raise ValueError("%s: column '%s' is not numeric (Real/Integer), its type is %s."
                             % (label, name, fld.typeName()))
        if not text and not fld.isNumeric():
            raise ValueError("%s: the type of column '%s' (%s) must be numeric or text."
                             % (label, name, fld.typeName()))
        spec = {"idx": idx, "text": text, "is_int": False, "dec": decimals, "name": name}
        if not text:
            is_shp = "shapefile" in (layer.storageType() or "").lower()
            if "int" in fld.typeName().lower():
                spec["is_int"] = True
                spec["dec"] = 0
                warnings.append("'%s' is an Integer field - values will be rounded to whole numbers."
                                % name)
            elif is_shp and fld.precision() == 0:
                spec["dec"] = 0
                warnings.append("'%s' (Shapefile) has decimal precision 0 - decimals will not be saved."
                                % name)
            elif is_shp and fld.precision() > 0:
                spec["dec"] = min(decimals, fld.precision())
        return spec

    def run_calculation(self):
        point_layer = self.point_cb.currentLayer()
        line_layer = self.line_cb.currentLayer()
        if point_layer is None or line_layer is None:
            self._error("Please select both a line layer and a point layer.")
            return
        if not point_layer.isValid() or not line_layer.isValid():
            self._error("One of the layers is not valid.")
            return
        warnings = []
        decimals = self.decimals_spin.value()
        coord_on = self.coord_box.isChecked()
        bear_on = self.bear_box.isChecked()
        coord_key, coord_prec = "MAP", self.coord_prec.value()
        bear_rng = bear_unit = None
        try:
            dist_spec = self._prep_field(point_layer, self.field_cb.currentField(),
                                         "Distance", False, True, decimals, warnings)
            x_spec = y_spec = b_spec = None
            if coord_on:
                coord_key = COORD_FORMATS[self.coord_fmt_cb.currentIndex()][1]
                need_text = coord_is_text(coord_key)
                x_spec = self._prep_field(point_layer, self.x_cb.currentField(), "X/Longitude",
                                          need_text, False, coord_prec, warnings)
                y_spec = self._prep_field(point_layer, self.y_cb.currentField(), "Y/Latitude",
                                          need_text, False, coord_prec, warnings)
            if bear_on:
                bear_rng = BEARING_RANGES[self.bear_range_cb.currentIndex()][1]
                bear_unit = self.bear_unit_cb.currentText()
                b_spec = self._prep_field(point_layer, self.bear_cb.currentField(), "Bearing",
                                          bearing_is_text(bear_rng, bear_unit), False,
                                          self.bear_prec.value(), warnings)
        except ValueError as e:
            self._error(str(e))
            return
        names = [s["name"] for s in (dist_spec, x_spec, y_spec, b_spec) if s]
        if len(set(names)) != len(names):
            self._error("Each output needs its own column (the same column is selected twice).")
            return
        if warnings and not self._ask("\n".join(warnings) + "\n\nContinue?"):
            return

        chosen = self._chosen_crs(point_layer, line_layer)
        if not chosen.isValid():
            self._error("The measurement CRS is not valid. Please check the layer CRS.")
            return
        ctx = QgsProject.instance().transformContext()
        planar = self.method_cb.currentIndex() == 1
        if planar:
            if chosen.isGeographic():
                self._error("Planar measurement needs a projected CRS (for example UTM). The selected "
                            "CRS is geographic (degrees). Choose the Ellipsoidal method or select a "
                            "projected CRS.")
                return
            work_crs = chosen
        else:
            work_crs = chosen
            if chosen.isGeographic():
               
                work_crs = self._auto_utm_crs(point_layer, line_layer, ctx)
                if work_crs is None:
                    self._error("Could not determine a local UTM zone. Please choose a projected CRS.")
                    return

        pt_tr = QgsCoordinateTransform(point_layer.crs(), work_crs, ctx)
        ln_tr = QgsCoordinateTransform(line_layer.crs(), work_crs, ctx)

        da = QgsDistanceArea()
        da.setSourceCrs(work_crs, ctx)
        if planar:
            da.setEllipsoid("NONE")
        else:
            ell = self.ell_cb.currentData()  # "" = project ellipsoid
            if not ell:
                ell = QgsProject.instance().ellipsoid()
            if not ell or ell == "NONE":
                ell = work_crs.ellipsoidAcronym() or "EPSG:7030"  # WGS84 fallback
            da.setEllipsoid(ell)

        out_tr = None
        if coord_on:
            if coord_key == "MAP" or point_layer.crs().isGeographic():
                out_crs = point_layer.crs()
            else:
                out_crs = QgsCoordinateReferenceSystem("EPSG:4326")
            out_tr = QgsCoordinateTransform(work_crs, out_crs, ctx)

        to_unit = self._units[self.unit_cb.currentIndex()][1]
        max_dist = self.max_spin.value()
        null_outside = self.null_outside_chk.isChecked()
        reverse = self.bear_dir_cb.currentIndex() == 1
        bear_prec = self.bear_prec.value()

        QApplication.setOverrideCursor(Qt.WaitCursor)
        self.run_btn.setEnabled(False)
        was_editing = point_layer.isEditable()
        try:
            # ---- Spatial index of the line layer (in the work CRS)
            self.status.setText("Building the line index...")
            QApplication.processEvents()
            index = QgsSpatialIndex()
            line_geoms = {}
            if self.sel_lines_chk.isChecked():
                line_iter = line_layer.getSelectedFeatures()
            else:
                line_iter = line_layer.getFeatures()
            for f in line_iter:
                g = f.geometry()
                if g is None or g.isNull() or g.isEmpty():
                    continue
                try:
                    g.transform(ln_tr)
                except Exception as e:
                    QgsMessageLog.logMessage("Line %s transform failed: %s" % (f.id(), e),
                                             LOG_TAG, Qgis.Warning)
                    continue
                nf = QgsFeature(f.id())
                nf.setGeometry(g)
                index.addFeature(nf)
                line_geoms[f.id()] = g

            if not line_geoms:
                self._error("No valid line was found in the line layer"
                            " (or no lines are selected).")
                return

            if not was_editing and not point_layer.startEditing():
                self._error("The point layer could not be switched to edit mode (it may be read-only).")
                return

            if self.sel_points_chk.isChecked():
                pts = list(point_layer.getSelectedFeatures())
            else:
                pts = list(point_layer.getFeatures())
            total = len(pts)
            if total == 0:
                self._error("No features were found in the point layer.")
                if not was_editing:
                    point_layer.rollBack()
                return

            extra_specs = [s for s in (x_spec, y_spec, b_spec) if s]
            self.progress.setRange(0, total)
            filled = skipped_far = skipped_bad = 0
            samples = []  # kept for the read-back verification and the Measure Tool check

            for i, feat in enumerate(pts):
                if i % 200 == 0:
                    self.progress.setValue(i)
                    self.status.setText("Processing %d / %d" % (i, total))
                    QApplication.processEvents()

                pg = feat.geometry()
                if pg is None or pg.isNull() or pg.isEmpty():
                    skipped_bad += 1
                    continue
                try:
                    pg.transform(pt_tr)
                except Exception:
                    skipped_bad += 1
                    continue

                res = best_distance(pg, index, line_geoms, da)
                if res is None:
                    skipped_bad += 1
                    continue
                raw, origin, foot = res

                value = da.convertLengthMeasurement(raw, to_unit)

                if max_dist > 0 and value > max_dist:
                    skipped_far += 1
                    if null_outside:
                        point_layer.changeAttributeValue(feat.id(), dist_spec["idx"], NULL)
                        for s in extra_specs:
                            point_layer.changeAttributeValue(feat.id(), s["idx"], NULL)
                    continue
                dval = round(value, dist_spec["dec"])
                dout = _to_db(dval, dist_spec)
                point_layer.changeAttributeValue(feat.id(), dist_spec["idx"], dout)
                filled += 1
                if len(samples) < 5 and not dist_spec["text"]:
                    samples.append((feat.id(), dout, value, origin, foot))
                if coord_on:
                    try:
                        fp = out_tr.transform(foot)
                        xv, yv = format_coord(fp.x(), fp.y(), coord_key, coord_prec)
                    except Exception:
                        xv = yv = None
                    point_layer.changeAttributeValue(feat.id(), x_spec["idx"], _to_db(xv, x_spec))
                    point_layer.changeAttributeValue(feat.id(), y_spec["idx"], _to_db(yv, y_spec))
                if bear_on:
                    bv = None
                    if raw > 1e-9:  # bearing is undefined when the point lies on the line
                        try:
                            ang = da.bearing(foot, origin) if reverse else da.bearing(origin, foot)
                            bv = format_bearing(math.degrees(ang) % 360.0, bear_rng,
                                                bear_unit, bear_prec)
                        except Exception:
                            bv = None
                    point_layer.changeAttributeValue(feat.id(), b_spec["idx"], _to_db(bv, b_spec))
            self.progress.setValue(total)
            if not was_editing:
                if not point_layer.commitChanges():
                    errs = "\n".join(point_layer.commitErrors())
                    point_layer.rollBack()
                    self._error("The changes could not be saved:\n" + errs)
                    return

            tol = 0.51 * (10 ** (-dist_spec["dec"])) + 1e-9
            bad = 0
            for fid, exp, _v, _o, _f in samples:
                try:
                    got = float(point_layer.getFeature(fid)[dist_spec["idx"]])
                    if abs(got - float(exp)) > tol:
                        bad += 1
                except Exception:
                    bad += 1
            verify = ("Verification: %d/%d sample values were saved correctly."
                      % (len(samples) - bad, len(samples)) if samples else "")
            mt_note = self._measure_tool_check(samples, work_crs, ctx, to_unit, dist_spec["dec"])
            mismatch = mt_note.startswith("Measure Tool mismatch")
            extras = []
            if coord_on:
                extras.append("coords")
            if bear_on:
                extras.append("bearing")
            how = "Planar" if planar else "Ellipsoidal"
            summary = ("Done - column '%s': %d filled, %d beyond the max distance, %d skipped. "
                       "[%s, CRS %s%s] %s %s"
                       % (dist_spec["name"], filled, skipped_far, skipped_bad, how,
                          work_crs.authid(), (", +" + "+".join(extras)) if extras else "",
                          verify, mt_note))
            if was_editing:
                summary += " (The layer is in edit mode - remember to save the edits.)"
            self.status.setText(summary)
            self._msg(summary, Qgis.Warning if (bad or mismatch) else Qgis.Success)
        except Exception as e:
            if not was_editing and point_layer.isEditable():
                point_layer.rollBack()
            QgsMessageLog.logMessage("Error: %r" % (e,), LOG_TAG, Qgis.Critical)
            self._error("Unexpected error: %s" % e)
        finally:
            QApplication.restoreOverrideCursor()
            self.run_btn.setEnabled(True)